const zlib = require("zlib");
const AWS = require("aws-sdk");

const ddb = new AWS.DynamoDB.DocumentClient();
const TABLE_NAME = "CloudPulseEvents";

function parseLog(message) {
    const log = message.trim();

    if (log.startsWith("START RequestId")) {
        const requestId = log.match(/RequestId:\s([a-zA-Z0-9-]+)/)?.[1] || "unknown";
        return { type: "START", requestId, message: log };
    }

    if (log.startsWith("END RequestId")) {
        const requestId = log.match(/RequestId:\s([a-zA-Z0-9-]+)/)?.[1] || "unknown";
        return { type: "END", requestId, message: log };
    }

    if (log.startsWith("REPORT RequestId")) {
        const requestId = log.match(/RequestId:\s([a-zA-Z0-9-]+)/)?.[1] || "unknown";
        const duration = log.match(/Duration:\s([0-9.]+)\sms/);
        const billed = log.match(/Billed Duration:\s([0-9.]+)\sms/);
        const memory = log.match(/Max Memory Used:\s([0-9.]+)\sMB/);

        return {
            type: "REPORT",
            requestId,
            durationMs: duration ? Number(duration[1]) : null,
            billedMs: billed ? Number(billed[1]) : null,
            memoryMb: memory ? Number(memory[1]) : null,
            message: log
        };
    }

    return {
        type: "INFO",
        requestId: "unknown",
        message: log
    };
}

exports.handler = async (event) => {
    console.log("SOURCE_EVENT:", JSON.stringify(event));

    if (!event.awslogs?.data) return { statusCode: 200 };

    const compressed = Buffer.from(event.awslogs.data, "base64");
    const decompressed = zlib.gunzipSync(compressed).toString("utf8");
    const data = JSON.parse(decompressed);

    const service = data.logGroup;

    const writes = [];

    for (const logEvent of data.logEvents || []) {
        const parsed = parseLog(logEvent.message);

        const item = {
            service,
            sk: `TIME#${logEvent.timestamp}#${parsed.requestId}`,

            type: parsed.type,
            requestId: parsed.requestId,

            // metrics (IMPORTANT FIX)
            durationMs: parsed.durationMs || null,
            billedMs: parsed.billedMs || null,
            memoryMb: parsed.memoryMb || null,

            message: parsed.message,
            raw: logEvent.message
        };

        writes.push(
            ddb.put({
                TableName: TABLE_NAME,
                Item: item
            }).promise()
        );
    }

    await Promise.all(writes);

    console.log(`Wrote ${writes.length} events`);

    return { statusCode: 200 };
};
