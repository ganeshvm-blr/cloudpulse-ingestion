const zlib = require("zlib");
const AWS = require("aws-sdk");

const ddb = new AWS.DynamoDB.DocumentClient();
const TABLE_NAME = "CloudPulseEvents";

function parseLog(message) {
    const parts = message.split("\t");

    if (parts.length < 3) {
        return {
            logType: "INFO",
            requestId: "unknown",
            message
        };
    }

    const msg = parts[2] || message;

    let logType = "INFO";
    if (msg.includes("START")) logType = "START";
    else if (msg.includes("END")) logType = "END";
    else if (msg.includes("REPORT")) logType = "REPORT";
    else if (msg.includes("ERROR")) logType = "ERROR";

    const requestIdMatch = msg.match(/RequestId:\s([a-zA-Z0-9-]+)/);
    const requestId = requestIdMatch ? requestIdMatch[1] : "unknown";

    return {
        logType,
        requestId,
        message: msg
    };
}

exports.handler = async (event) => {
    console.log("SOURCE_EVENT:", JSON.stringify(event));

    if (!event.awslogs?.data) {
        console.log("No CloudWatch payload");
        return { statusCode: 200 };
    }

    const compressed = Buffer.from(event.awslogs.data, "base64");
    const decompressed = zlib.gunzipSync(compressed).toString("utf8");
    const data = JSON.parse(decompressed);

    const service = data.logGroup || "unknown-service";

    let writeCount = 0;

    for (const logEvent of data.logEvents || []) {
        const parsed = parseLog(logEvent.message);

        const item = {
            pk: `SERVICE#${service}`,
            sk: `TIME#${logEvent.timestamp}#${parsed.requestId}`,

            service,
            timestamp: logEvent.timestamp,

            logType: parsed.logType,
            requestId: parsed.requestId,
            message: parsed.message,

            raw: logEvent.message
        };

        try {
            await ddb.put({
                TableName: TABLE_NAME,
                Item: item
            }).promise();

            writeCount++;
        } catch (err) {
            console.error("DynamoDB write failed:", err);
        }
    }

    console.log(`Wrote ${writeCount} events to DynamoDB`);

    return { statusCode: 200 };
};
